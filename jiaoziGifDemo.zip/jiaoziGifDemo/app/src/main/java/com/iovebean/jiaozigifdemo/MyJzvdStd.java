package com.iovebean.jiaozigifdemo;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.os.Environment;
import android.provider.Settings;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



import java.io.File;

import cn.jzvd.JZUtils;
import cn.jzvd.JzvdStd;



class MyJzvdStd extends JzvdStd implements GifCreateHelper.JzGifListener{


    GifCreateHelper mGifCreateHelper;

    TextView tv_hint;
    FrameLayout fl_hint_region;
    ImageView convert_to_gif;

    String saveGifPath;
    private ImageView screenshort;



    @Override
    public void init(Context context) {
        super.init(context);

        tv_hint = findViewById(R.id.tv_hint);
        fl_hint_region = findViewById(R.id.fl_hint_region);
        convert_to_gif = findViewById(R.id.convert_to_gif);
        screenshort = findViewById(R.id.screenshort);
        screenshort.setOnClickListener((new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "保存图片", Toast.LENGTH_SHORT).show();
                long currentPosition = MyJzvdStd.this.getCurrentDuration();
                if (currentPosition >= 300) {
                    MyJzvdStd.this.seekto(currentPosition - 300);
                }
                Bitmap capture = null;

                capture = MyJzvdStd.this.textureView.getBitmap();
                if (capture == null) {
                    Toast.makeText(getApplicationContext(), "失败", Toast.LENGTH_SHORT).show();
                } else {
            //做保存
                    Toast.makeText(getApplicationContext(), "成功", Toast.LENGTH_SHORT).show();
                }
            }
        }));

        convert_to_gif.setOnClickListener((v -> {

            int scale =1;
            int speed=1;
            int gifspeed=1000;
            int period =5000;
            tv_hint.setText("正在创建Gif..."+"scale_"+scale+" speed_"+ speed +" 间隔_"+gifspeed +" 长度_"+period);
            fl_hint_region.setVisibility(View.VISIBLE);

            /*saveGifPath = Environment
                    .getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/jiaozi-" + System.currentTimeMillis() + ".gif";*/


            int gifspeed2;

            gifspeed2 = (int) (gifspeed/speed);
            saveGifPath= Environment.getExternalStorageDirectory() + "/bbBrowsers" + "/gif/" + "/gif_"+scale+"_"+
                    speed +"_"+gifspeed +"_"+period+"_"+ System.currentTimeMillis() + ".gif";

            mGifCreateHelper = new GifCreateHelper(this, this, (int) gifspeed,
                    1, scale, period, saveGifPath,gifspeed2);

            mGifCreateHelper.startGif();//这个函数里用了jzvd的两个参数。
            try {
                mediaInterface.pause();
                onStatePause();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }));

        topContainer.setOnTouchListener((v, event) -> true);
        fl_hint_region.setOnTouchListener((v, event) -> true);
    }


    @Override
    public void process(int curPosition, int total, String status) {
        Log.e("Jzvd-gif", status + "  " + curPosition + "/" + total);
        post(() -> tv_hint.setText(curPosition + "/" + total + " " + status));
    }



    @Override
    public void result(boolean success, File file) {
        fl_hint_region.setVisibility(View.GONE);
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getContext(), getContext().getString(R.string.creategifmsg) + saveGifPath, Toast.LENGTH_LONG).show();

            }
        },500);
    }

    @Override
    public int getLayoutId() {
        return R.layout.jz_layout_gif;
    }

    @Override
    public void onClickUiToggle() {
        super.onClickUiToggle();

            if (bottomContainer.getVisibility() == View.VISIBLE) {
                convert_to_gif.setVisibility(View.VISIBLE);
                screenshort.setVisibility(View.VISIBLE);
            } else {
                convert_to_gif.setVisibility(View.GONE);
                screenshort.setVisibility(View.GONE);
        }
    }

    @Override
    public void setScreenFullscreen() {
        super.setScreenFullscreen();
        convert_to_gif.setVisibility(View.VISIBLE);
        screenshort.setVisibility(View.VISIBLE);
    }

    @Override
    public void dissmissControlView() {
        super.dissmissControlView();
        post(() -> {

                convert_to_gif.setVisibility(View.GONE);
                screenshort.setVisibility(View.GONE);
                bottomProgressBar.setVisibility(View.GONE);

        });
    }

    @Override
    public void changeUiToPlayingClear() {
        super.changeUiToPlayingClear();
        if (screen == SCREEN_FULLSCREEN) {
            bottomProgressBar.setVisibility(GONE);
            convert_to_gif.setVisibility(View.GONE);
            screenshort.setVisibility(View.GONE);
        }
    }

    @Override
    public void setScreenNormal() {
        super.setScreenNormal();
        convert_to_gif.setVisibility(View.GONE);
        screenshort.setVisibility(View.GONE);
    }
    public MyJzvdStd(Context context, AttributeSet attrs) {
        super(context, attrs);
        setKeepScreenOn(true);

    }




    public MyJzvdStd(Context context) {
        super(context);
        setKeepScreenOn(true);
    }





    public void seekto(Long duration){

        if(state==STATE_PLAYING)
            mediaInterface.seekTo(duration);
    }
    public  Long getCurrentDuration(){
        if(state==STATE_PLAYING)
            return mediaInterface.getCurrentPosition();
        return 0l;
    }
    public  void setVolume(float l,float r){
        if(state==STATE_PLAYING)
        mediaInterface.setVolume(l,r);

    }

    @Override
    public void onVideoSizeChanged(int width, int height) {
        super.onVideoSizeChanged(width, height);
    }

    public void setVideoSize(int width, int height) {
        //JZMediaManager.textureView.setVideoSize(textureViewContainer.getWidth(),textureViewContainer.getHeight());//视频大小与控件大小一致
        if(textureView!=null)
        textureView.setVideoSize(width,height);
    }

    public  void setSpeed(float speed){

        if(state==STATE_PLAYING)
            mediaInterface.setSpeed(speed);
    }


/*    @Override
    public void setScreenFullscreen() {
       super.setScreenFullscreen();

    }*/

    @Override
    public void gotoScreenFullscreen() {
        super.gotoScreenFullscreen();
    }

    public static boolean backPress() {
        Log.i(TAG, "backPress");
        if (CONTAINER_LIST.size() != 0 && CURRENT_JZVD != null) {//判断条件，因为当前所有goBack都是回到普通窗口
            CURRENT_JZVD.gotoScreenNormal();
            return true;
        } else if (CONTAINER_LIST.size() == 0 && CURRENT_JZVD != null && CURRENT_JZVD.screen != SCREEN_NORMAL) {//退出直接进入的全屏
            CURRENT_JZVD.clearFloatScreen();
            return true;
        }
        return false;
    }

}
