package com.iovebean.jiaozigifdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

import cn.jzvd.JzvdStd;

public class MainActivity extends AppCompatActivity {

    public  MyJzvdStd jzvdStd;

    private void initPermission(){
        String[] permissions = {
                Manifest.permission.INTERNET,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
        };
        ArrayList<String> toApplyList = new ArrayList<>();

        for (String perm : permissions) {
            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, perm)) {
                toApplyList.add(perm);
                // 进入到这里代表没有权限.
            }
        }
        String[] tmpList = new String[toApplyList.size()];
        if (!toApplyList.isEmpty()) {
            ActivityCompat.requestPermissions(this, toApplyList.toArray(tmpList), 123);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //在虚拟机上测试成功,在真机上打不开视频,不知道哪里错了,懒得搞了
        setContentView(R.layout.activity_main);
        initPermission();
         jzvdStd = findViewById(R.id.player);
        jzvdStd.setUp(
                "http://fs.mv.web.kugou.com/202004282228/93cebdc4221229700b6f0b07cd5b2803/G213/M08/12/1D/dYcBAF6kfvCAXkIJAPNHaG9mcHo090.mp4", "", JzvdStd.SCREEN_NORMAL,
                JZMediaExo.class);

    }
}
